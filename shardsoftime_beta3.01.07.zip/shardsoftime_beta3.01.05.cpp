#include <iostream>
#include <chrono>
#include <thread>
#include <cstdlib>
#include <fstream>
#include <list>
#include <vector>
#include <sstream>
#include <cctype>
#include <algorithm>
#include <variant>


using namespace std;
using namespace std::this_thread;
using namespace std::chrono;
using stringorint = std::variant<std::string, int, bool>;

int conv_to_int(const string& str){
    stringstream ss(str);
    int result = 0;
    ss >> result;
    return result;
}



string one_front(string name, string enemy1){
    string out;
    
    out += "\n----------------------------------------\n\n\n";
    out += name;
    out += string(3, ' ');
    out += "VS";
    out += string(3, ' ');
    out += enemy1;
    out += string(5, ' ');
    out += "\n\n\n----------------------------------------\n";
    
    return out;
}

string two_front(string name, string enemy1, string enemy2){
    string out;
    
    out += "\n----------------------------------------\n\n\n";
    out += string(name.length()+8, ' ');
    out += enemy1;
    out += "\n";
    out += name;
    out += string(3, ' ');
    out += "VS";
    out += "\n";
    out += string(name.length()+8, ' ');
    out += enemy2;
    out += "\n\n\n----------------------------------------\n";
    return out;
}

string one_front_one_back(string name, string enemy1, string enemy2){
    string out;
    
    out += "\n----------------------------------------\n\n\n";
    out += name;
    out += string(3, ' ');
    out += "VS";
    out += string(3, ' ');
    out += enemy1;
    out += string(5, ' ');
    out += enemy2;
    out += "\n\n\n----------------------------------------\n";
    
    return out;
}




string attack(string attacker, string victim, int damage){
    int start = victim.length() - 8;
    
    string v_hp_str = victim.substr(start, 3);
    
    if (v_hp_str[0] == 0){
        v_hp_str = v_hp_str.substr(1,v_hp_str.length()-1);
    }
    
    int v_hp = conv_to_int(v_hp_str);

    start = victim.length() - 4;
    string v_tot_str = victim.substr(start, 3);
    
    if (v_tot_str[0] == 0){
        v_tot_str = v_tot_str.substr(1,v_tot_str.length()-1);
    }
    
    int v_tot = conv_to_int(v_tot_str);
    
    v_hp -= damage;
    
    int index = victim.find("["); 
    string vic_name = victim.substr(0,index);
    
    string fin_hp = to_string(v_hp);
    char first = fin_hp[0];
    
    if (fin_hp.length() == 2 and first != '-'){
        fin_hp = '0' + fin_hp;
    } else if (fin_hp.length() == 1 and first != '-'){
        fin_hp = '0' + fin_hp;
        fin_hp = '0' + fin_hp;
    }
    
    string fin_tot = to_string(v_tot);

    
    if (fin_tot.length() < 3){
        fin_tot = '0' + fin_tot;
    }
    
    string out = vic_name;
    out += "[";
    out += fin_hp;
    out += "/";
    out += fin_tot;
    out += "]";
    
    cout << "\n" << attacker << " dealt " << damage << " dmg to " << out << endl;
    
    sleep_for(seconds(2));
    
    return out;
}

int one_battle(string name, vector<stringorint> e1, int sword_damage, int ap){
    
    cout << "\n\n\n\n\nBATTLE BEGIN:\n\n";
    
    string enemy1 = "1. " + get<string>(e1[0]);
    int enemy1_damage = get<int>(e1[1]);
    bool e1_back = get<bool>(e1[2]);
    int e1_xp = get<int>(e1[3]);
    
    int damage = ap + sword_damage;
    int p_hp = conv_to_int(name.substr(name.length()-8, 3));
    int e1_hp = conv_to_int(enemy1.substr(enemy1.length()-8, 3));
    
    
    
    
    
    while ((p_hp > 0) and (e1_hp > 0)){
        string printed = one_front(name,enemy1);
        cout << printed;
        
        string choice;
        cout << "Please enter the number of the enemy you wish to attack:";
        cin >> choice;
        
        int x = 1;
        string chosen_enemy;
        
        while (x == 1){
            if (choice == "1"){
                chosen_enemy = enemy1;
                x = 0;
            }
            
            else {
                cout << endl << "Please re-enter enemy number:";
                cin >> choice;
            }
            
        }

        string outcome = attack(name, chosen_enemy, damage);
        
        if (chosen_enemy == enemy1){
            enemy1 = outcome;
        }
        
        e1_hp = conv_to_int(enemy1.substr(enemy1.length()-8, 3));
        
        
        if (e1_hp < 1){
            break;
        }
        
        name = attack(enemy1, name, enemy1_damage);
        p_hp = conv_to_int(name.substr(name.length()-8, 3));
        
    }
    
    if (p_hp < 1){
        sleep_for(seconds(1));
        cout << "\nYou died.\n\n\n\n";
        sleep_for(seconds(1));
        cout << "GAME OVER";
        return 0;
    }
    
    else {
        sleep_for(seconds(1));
        cout << "\nYou won! Congratulations!\nYou gained" << e1_xp << " xp\n";
        return e1_xp;
    }
    
    
}

int two_battle(string name, vector<stringorint> e1, vector<stringorint> e2, int sword_damage, int ap, string battle_type){
        
    cout << "\n\n\n\n\nBATTLE BEGIN:\n\n";
    
    string enemy1 = "1. " + get<string>(e1[0]);
    int enemy1_damage = get<int>(e1[1]);
    bool e1_back = get<bool>(e1[2]);
    int e1_xp = get<int>(e1[3]);
    
    string enemy2 = "2. " + get<string>(e2[0]);
    int enemy2_damage = get<int>(e2[1]);
    bool e2_back = get<bool>(e2[2]);
    int e2xp = get<int>(e2[3]);
    
    int tot_xp = e1_xp + e2xp;
    
    
    int damage = ap + sword_damage;
    int p_hp = conv_to_int(name.substr(name.length()-8, 3));
    int e1_hp = conv_to_int(enemy1.substr(enemy1.length()-8, 3));
    int e2_hp = conv_to_int(enemy2.substr(enemy2.length()-8, 3));
    int tot_enemy_hp = e1_hp + e2_hp;
    vector<string> defeated = {"nobody"};
    
    while ((p_hp > 0) and (e1_hp > 0 or e2_hp > 0)){
        
        string printed;
        
        if (battle_type == "2f"){
            printed = two_front(name,enemy1,enemy2);
        } else if (battle_type == "1f1b"){
            printed = one_front_one_back(name, enemy1, enemy2);
        }
        
        cout << printed;
        
        string choice;
        cout << "Please enter the number of the enemy you wish to attack:";
        cin >> choice;
        
        int x = 1;
        string chosen_enemy;
        
        while (x == 1){
            if (choice == "1"){
                if (e1_hp < 1){
                    cout << "This enemy has already been defeated. Please re-enter the number: ";
                    cin >> choice;
                } else {
                    chosen_enemy = enemy1;
                    x = 0;
                }
            } else if (choice == "2"){
                if (e2_hp < 1){
                    cout << "This enemy has already been defeated. Please re-enter the number: ";
                    cin >> choice;
                } else if (e1_hp > 1 and e2_back == true){
                    cout << "You cannot attack this enemy yet. Please re-enter the number: ";
                    cin >> choice;
                } else {
                    chosen_enemy = enemy2;
                    x = 0;
                }
            } else {
                cout << "Please re-enter the number: ";
                cin >> choice;
            }
        }

        string outcome = attack(name, chosen_enemy, damage);
        
        if (chosen_enemy == enemy1){
            enemy1 = outcome;
            e1_hp = conv_to_int(enemy1.substr(19, 3));
            
        } else if (chosen_enemy == enemy2){
            enemy2 = outcome;
            e2_hp = conv_to_int(enemy2.substr(19, 3));
            
        }
        
        if (e1_hp > 0){
            name = attack(enemy1, name, enemy1_damage);
            p_hp = conv_to_int(name.substr(name.length()-8, 3));
            if (p_hp < 1){
                break;
            }
        } else {
            e1_hp = 0;
            defeated.push_back(enemy1);
        }
        
        if (e2_hp > 0){
            name = attack(enemy2, name, enemy2_damage);
            p_hp = conv_to_int(name.substr(name.length()-8, 3));
            if (p_hp < 1){
                break;
            }
        } else {
            e2_hp = 0;
            defeated.push_back(enemy2);
        }
      
        tot_enemy_hp = e1_hp + e2_hp;

    }
    
    if (p_hp < 1){
        sleep_for(seconds(1));
        cout << "\nYou died.\n\n\n\n";
        sleep_for(seconds(1));
        cout << "GAME OVER";
        return 0;
    }
    
    else {
        sleep_for(seconds(1));
        int xp_gain = 40;
        cout << "\nYou won! Congratulations!\nYou gained " << tot_xp << " xp\n";
        return tot_xp;
    }
    
    
}

int save(string name, string checkpoint, int hp, int ap, int sp, int mp, int lvl, int xp, int total_temples, string weapon, int wdmg){
    
    // Clears out backup file
    ofstream bckp_clr("backup.txt");
    string newContent;  // Blank btw
    bckp_clr << newContent; // Now all of file is just ""
    bckp_clr.close();

    // Writes save data to backup file
    fstream bckp_wrt;
    bckp_wrt.open("backup.txt", ios::app);
    bckp_wrt << name << endl << checkpoint << endl << hp << endl << ap << endl << sp << endl << mp << endl << lvl << endl << xp << endl << total_temples << endl << weapon << endl <<  wdmg;
    bckp_wrt.close();
    
    // Clears out player file
    string filename = name + ".txt";
    ofstream plyrClr(filename);
    plyrClr << newContent;
    plyrClr.close();

    // Writes save data to player file
    fstream plyrWrt;
    plyrWrt.open(filename, ios::app);
    plyrWrt << name << endl << checkpoint << endl << hp << endl << ap << endl << sp << endl << mp << endl << lvl << endl << xp << endl << total_temples << endl << weapon  << endl <<  wdmg;
    plyrWrt.close();
    
    cout << "\n\n// Your data has been saved. For data to save, the game's execution must end. Please re-run the code and select 'b' in the startup menu to resume your progress from your last checkpoint. Sorry for the inconvenience.";
    
    
    return 0;
}




vector<int> levelup(int hp, int ap, int sp, int mp, int xp, int lvl){
    vector<int> fakeout = {0}; 
    
    if (lvl < 6){
        if (xp > 49){
            lvl += 1;
            xp = xp-50;
        } else {
            return fakeout;
        }
    } else if (lvl < 11){
        if (xp > 74){
            lvl += 1;
            xp = xp-50;
        } else {
            return fakeout;
        }
    }
    
    sleep_for(seconds(2));
    
    cout << "\n\n// LEVEL UP!\n\n// You can choose two stats to increase by 1 (HP will increase by 5). You can choose the same stat twice.\n";
    string choice;
    
    for (int i = 0; i < 2; i++){
        cout << "Choose stat " << i+1  << ": HP, AP, SP or MP\n:";
        cin >> choice;
        
        transform(choice.begin(), choice.end(), choice.begin(), ::tolower);
        
        if (choice == "hp"){
            hp += 5;                                                                                                                                         
        }else if (choice == "ap"){
            ap += 1;
        }else if (choice == "sp"){
            sp += 1;
        }else {
            mp += 1;
        }
    }
    
    

    vector<int> out = {hp,ap,sp,mp,xp,lvl};
    return out;
}




int main(){
    
    string name;
    
    cout << "===== SHARDS OF TIME =====\n\n\n";
    
    string save_game;
    cout << "Would you like to start a new save file (a), or keep playing an old one (b)?: ";
    cin >> save_game;
    
    // For new users
    
    if (save_game == "a"){

        ifstream nametest("Names.txt");
        
        // introduction / title & name input
        cout << "\n\n\nBefore you start, please enter the name of your character (make sure to include no spaces): ";
        string name;
        cin >> name;
        
        int counter = 0;
        string line;
        
        while (getline(nametest,line)){
            if (line == name){
                cout << "Name in use, please enter another: ";
                cin >> name;
            }
            else {
                break;
            }
            counter++;
        }
    
        
        nametest.close();
        
        
        cout << "[Please scroll to bottom]\n";
        
        for (int i = 0; i<100; i++){
            cout << "\n";
        }
        
        // Wake up sequence
        
        string choice;
        
        if (name != "test"){
            cout << "??? - " << name << "...";
            
            sleep_for(seconds(2));
            
            for (int z = 0; z<10; z++){
                    cout << "\n";
            }
            
            cout << "??? - " << name << "...";
            sleep_for(seconds(2));
            cout << ".\n";
            sleep_for(seconds(2));
            
            for (int z = 0; z<10; z++){
                cout << "\n";
            }
            
            cout << "Wake up " << name << "!";
            
            sleep_for(seconds(2));
            
            for (int z = 0; z<10; z++){
                cout << "\n";
            }
            
            
        
        
            // First dialogue with MC
            
            cout << "??? - Wake up!!\n\n1) What?\n2) Where am I?  [press the NUMBER of your selection]\n:";
            string choice;
            cin >> choice;
            
            if (choice == "1"){
                cout << "\n"<< name << "- What?\n\n";
            }
            
            else if (choice == "2"){
                cout << "\n" << name << "- Where am I?\n\n";
            }
            
            cout << "/// You wake up and find yourself what seems to be a long forgotten temple. You try to remember how you got here, but it feels like there's some sort of fog in your mind.\n\n";
            
            sleep_for(seconds(5));
            
            cout << "??? - Good. You're awake now. Took you long enough. Almost 100 years, in fact!\n\n1) What do you mean 100 years!\n2) Who are you?\n:";
            cin >> choice;
            
            sleep_for(seconds(1));
            
            if (choice == "1"){
                cout << "\n"<< name << " - What do you mean 100 years!\n\n";
            }
            
            else if (choice == "2"){
                cout << "\n"<< name << " - Who are you?\n\n";
            }
            
            cout << "??? - For starters, I don't know who I am. I think I'm not really a person, more of a memory, or an imprint of someone that used to exist. But anyway, you can call me Echo, I guess?\n\n";
            
            sleep_for(seconds(10));
            
            cout << "1) How did I get here?\n2) How did I end up like this?\n:";
            cin >> choice;
            
            if (choice == "1"){
                cout << "\n"<< name << "- How did I get here?\n\n";
            }
            
            else if (choice == "2"){
                cout << "\n" << name << "- How did I end up like this?\n\n";
            }
            
            cout << "Echo - That's a tricky question. And an even longer story. I'd better start with the start of what I know: 300 years ago, this land was once known as the Kronian Kingdom. All was well, until a shadow was suddenly cast over the moon one night. Like some great bat, a hazy dark figure swept down from the heavens. Landing in the Grand Citadel of Kronovia, its malevolant shadow spread out across our once beautiful lands, polluting all it came into contact with. They called it by many names, The Bloodborne, The Shadow Weaver, but most often, the Devil of Darkness. He and his evil forces, born from the tainted shadows of his devise, destroyed the land, ravaged homes, and left no survivors...\n\n";

            sleep_for(seconds(35));
        
            
            cout << "1) What about me, how am I still alive?\n2) How did I end up here then?\n:";
            cin >> choice;
            
            if (choice == "1"){
                cout << "\n"<< name << "- What about me, how am I still alive?\n\n";
            }
            
            else if (choice == "2"){
                cout << "\n" << name << "- How did I end up here then?\n\n";
            }
            
            sleep_for(seconds(1));
            
            cout << "Echo - Wait a minute, I was just getting to that part! Before that fateful night, you were revered as the most skilled knight in Kronovia, humanity's strongest soldier. It was agreed as a last minute decision by King Kronos that you would be sent into a form of temporal stasis; no time has passed for you in the last 100 years, but the world around you has changed dramatically. You were sealed off in this temple, before the Shadow of the Devil of Darkness could reach here, and only now have you been awakened, to defeat Mephisto and to find a way to bring back humanity.\n\n";
            
            cout << "1) That sounds much easier said than done.\n2) But how would I even go about doing that?\n:";
            cin >> choice;
            
            sleep_for(seconds(1));
            
            if (choice == "1"){
                cout << "\n"<< name << "- That sounds much easier said than done.\n\n";
            }
            
            else if (choice == "2"){
                cout << "\n" << name << "- But how would I even go about doing that?\n\n";
            }
            
            sleep_for(seconds(1));
    
            cout << "Echo - It won't be easy. You'll need to travel to various temples, just like this one, and regain your old skills. I assume you've basically forgotten everything about how to fight? At each of these temples, you will learn a new way fighting technique.\n\n";
            
            sleep_for(seconds(10));
            
            cout << "1) Where am I meant to start?\n2) Where sould I go first?\n:";
            cin >> choice;
            
            sleep_for(seconds(1));
            
            if (choice == "1"){
                cout << "\n"<< name << "- Where am I meant to start?\n\n";
            }
            
            else if (choice == "2"){
                cout << "\n" << name << "- Where shoul I go first?\n\n";
            }
            
            sleep_for(seconds(1));
            
            cout << "Echo - You can start here. There are five temples that you must travel to on your journey: The Swordsman's Temple (here), The Knife Thrower's Temple, The Archer's Temple, The Executioner's Temple and The Mage's Temple. First, you will need to complete The Swordsman's Temple here though. If you enter through that door in front of you, you can begin the trials.\n\n";
            
            sleep_for(seconds(15));
    
        }
        
        
        
        cout << "/// You walk through the open doorway, batting away cobwebs from your face...\n\n";
        
        
        fstream file;
        file.open("Names.txt", ios::app);
        file << name << "\n";
        
        string namefilename = name + ".txt";
        
        
        
        for (int i = 0; i<100; i++){
            cout << "\n";
        }
        
        int hp_add;
        int ap_add;
        int sp_add;
        int mp_add;
        int total = hp_add + ap_add + sp_add + mp_add;
        
        cout << "/// Character attribute selection. Here you can modify your character's base stats. They are: HP (health points), AP (attack points, added as a bonus to the damage of your weapon), SP (speed points, affecting the order of turns in a battle round), and MP (magic points, influencing how powerful your magical abilities are). You get a total of 20 points to add across all four stats, and each of them come with a base stat of 5. You can add a maximum of 15 points to each stat. The HP stat will be multipliied by 10 after your selection, so having 10 total points gives you 100 HP, and this applies only to the HP stat. Please choose wisely, as this can greatly affect your gameplay, and cannot be changed mid-game:\n\n";
        
        while (total != 20){
        
            cout << "Enter HP stat: 5 + ";
            cin >> hp_add;
            
            cout << "Enter AP stat: 5 + ";
            cin >> ap_add;
            
            cout << "Enter SP stat: 5 + ";
            cin >> sp_add;
            
            cout << "Enter MP stat: 5 + ";
            cin >> mp_add;
            
            total = hp_add + ap_add + sp_add + mp_add;
            
            if (total != 20){
                cout << "Please re-enter values, something went wrong.\n\n";
            }
        
        }
        
        string checkpoint = "start_temple_1";
        int hp = (5 + hp_add) *10;
        int ap = 5 + ap_add;
        int sp = 5 + sp_add;
        int mp = 5 + mp_add;
        int lvl = 1;
        int xp;
        int total_temples;
        string weapon = "nope";
        int wdmg;
        
        
        
        
        int temp = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
        
        
        
        
        
        
        cout << "\n\n/// For the game to save, you must quit the game. You can instantly return to where you are now, by selecting 'b' at the start.";
        return 0;
    
    }
    
    // For existing users
    
    else {
        
        // Finds previous save files
        
        string name;
        cout << "Please enter the player name of the save file you wish to use: ";
        cin >> name;
        
        ifstream nametest("Names.txt");
        
        
        string line;
        line = "";
        int counter;
        int nocounter;
        
        while (1==1){
            nametest.clear(); 
            nametest.seekg(0);
            
            
            line = "";
            counter = 0;
            nocounter = 0;
            while (getline(nametest,line)){
                if (line == name){
                    counter++;
                    break;
                }
                else {
                    nocounter++;
                }
                counter++;
            }
            
            if (counter == nocounter){
                cout << "Your name was not found, please enter a valid name: ";
                cin >> name;
            }
            
            else {
                break;
            }
        
        }
        
        nametest.close();
        
        
        cout << "Welcome back, " << name << ".\n\n";
        
        sleep_for(seconds(2));
    

        string namefilename = name + ".txt";
        
        line = "";
        ifstream get(namefilename);
        
        // Gets each stat as a string from player file
        // "s" before variable name indicates variable marked to be converted, eg: "shp" instead of "hp"
        
        string checkpoint;
        string shp;
        string sap, ssp, smp, slvl, sxp, stotal_temples, weapon, swdmg;
        
        getline(get,name);
        getline(get,checkpoint);
        getline(get,shp);
        getline(get,sap);
        getline(get,ssp);
        getline(get,smp);
        getline(get,slvl);
        getline(get,sxp);
        getline(get,stotal_temples);
        getline(get,weapon);
        getline(get,swdmg);
        
        get.close();
        
        // Converts necessary variables to integers
        
        int hp = conv_to_int(shp);
        int ap = conv_to_int(sap);
        int sp = conv_to_int(ssp);
        int mp = conv_to_int(smp);
        int lvl = conv_to_int(slvl);
        int xp = conv_to_int(sxp);
        int total_temples = conv_to_int(stotal_temples);
        int wdmg = conv_to_int(swdmg);
        
        if (shp.length() < 3){
            shp = "0" + shp;
        }
        
        
        
        
        
        
        for (int i = 0; i<100; i++){
            cout << "\n";
        }
        
        
        
        
        
        
        
        int battle_out;
        
        vector<stringorint> s_knight = {string("Soulless_Knight[090/090]"), 5, false, 20};
        vector<stringorint> s_archer = {string("Soulless_Archer[090/090]"), 10, true, 30};
        vector<stringorint> s_sentinel = {string("Soulless_Sentinel[130/130]"), 15, false, 40};
        
        string fullname = name + "[" + shp + "/" + shp + "]";
        
        vector<int> values;
        
        int finish;
        
        
        
        
        
        
        
        
        
        
        
        if (checkpoint == "start_temple_1"){
            cout << "/// You walk through the crumbled remains of a grand entrance to a high-ceilinged chamber. In front of you lies a pedestal, and atop that, a sword.\n\n\n";
            sleep_for(seconds(5));
            cout << "Echo - Do you see that sword over there? Go over and pick it up, see what happens if you do...\n\n[Press A then ENTER to pick up sword] :";
            
            sleep_for(seconds(1));
            
            string choice;
            cin >> choice;
            
            cout << "??? - WELCOME FALLEN HERO....";
            sleep_for(seconds(2));
            cout << "\n\n??? - WECLOME TO THE TEMPLE OF THE SWORDSMAN, HERO OF OLD. 100 LONG YEARS HAVE PASSED SINCE WE MONKS SACRIFICED OUR LIVES TO SAVE OUR NATION. OUR PURPOSE IS TO TEACH YOU HOW TO USE DIFFERENT WEAPONS AND MODES OF COMBAT, AND FOR YOU TO REMEMBER YOUR FORMER GLORY. HERE YOU WILL MASTER THE SKILL OF SWORDSMANSHIP. WHEN YOU PASS INTO THE NEXT ROOM, THERE WILL BE ONE SOULLESS KNIGHT BEFORE YOU. YOU MUST DEFEAT IT IN COMBAT.\nTO KILL THESE KNIGHTS, YOU MUST KNOCK DOWN THEIR HP ATTACK BY ATTACK UNTIL IT GOES BELOW ZERO. GOOD LUCK...\n\n\n";
            
            sleep_for(seconds(10));
            
            cout << "/// You aquired the TRAINING SWORD [10 DMG]\n";
            weapon = "Training_Sword";
            wdmg = 10;
            
            sleep_for(seconds(1));
            
            cout << "/// The amount of damage that you will deal with every attack is the combination of the damage of your most powerful sword, and your base attack stat.\n\n";
            
            sleep_for(seconds(3));
            
            
            
            
            
            
            
            
            battle_out = one_battle(fullname, s_knight, wdmg, ap);
            
            
            
            
            
            if (battle_out == 0){
                finish = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
                return 0;
            }
            xp += battle_out;
            
            
            
            
            if (values[0] != 0){
                hp = values[0];
                ap = values[1];
                sp = values[2];
                mp = values[3];
                xp = values[4];
                lvl = values[5];
                fullname = name + "[" + to_string(hp) + "/" + to_string(hp) + "]";
            } else {
                cout << "// No level up available at this moment.\n\n\n";
            }

            sleep_for(seconds(1));
            
            cout << "??? - CONGRATULATIONS " << name << ". IT APPEARS YOU STILL RETAIN SOME OF YOUR FORMER SKILLS. HOWEVER, THE NEXT ROOM WILL NOT BE SO EASY. THERE WILL BE TWO SOULLESS KNIGHTS TO FIGHT. GOOD LUCK...\n";
            sleep_for(seconds(4));
            
            battle_out = two_battle(fullname, s_knight, s_knight, wdmg, ap, "2f");
            
            if (battle_out == 0){
                finish = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
                return 0;
            }
            xp += battle_out;
            
            
            values = levelup(hp,ap,sp,mp,xp,lvl);
            
            if (values[0] != 0){
                hp = values[0];
                ap = values[1];
                sp = values[2];
                mp = values[3];
                xp = values[4];
                lvl = values [5];
            } else {
                cout << "// No level up available at this moment.\n\n\n";
            }

            sleep_for(seconds(1));
            checkpoint = "mid_temple_1";
            finish = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
            return 0;
            
        }
        
        
        
        if (checkpoint == "mid_temple_1"){
            cout << "??? - WELL DONE " << name << ". YOU HAVE FOUGHT WELL. IN THE NEXT ROOM, YOU WILL FACE TWO NEW TYPES OF ENEMY: THE SOULLESS ARCHER AND THE SOULLESS SENTINEL. TO DEFEAT THE ARCHER, YOU MUST FIRST DEFEAT ALL ENEMIES THAT STAND BEFORE IT. SENTINELS ARE AKIN TO THE REGULAR KNIGHT, YET MORE POWERFUL AND DURABLE IN EVERY WAY. THEY WILL BE A CHALLENGE FOR YOU TO DEFEAT. ENTER, IF YOU DARE...\n\n";
            sleep_for(seconds(4));
            cout << "\n/// You walk through a doorway on your right, into the next room. A Soulless Knight and a Soulless Archer await you.\n";
            sleep_for(seconds(1));
            cout << "/// Enemies like archers in the furthest column from you can only be defeated after the enemies before it have also been defeated.\n\n";
            sleep_for(seconds(3));
            
            battle_out = two_battle(fullname, s_knight, s_archer, wdmg, ap, "1f1b");
            
            
            if (battle_out == 0){
                finish = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
                return 0;
            }
            xp += battle_out;
            
            
            values = levelup(hp,ap,sp,mp,xp,lvl);
            
            if (values[0] != 0){
                hp = values[0];
                ap = values[1];
                sp = values[2];
                mp = values[3];
                xp = values[4];
                lvl = values [5];
            } else {
                cout << "// No level up available at this moment.\n\n\n";
            }
            
            
            sleep_for(seconds(2));
            
            cout << "??? - YOUR NEXT FIGHT WON'T BE SO EASY. A SOULLESS SENTINEL AWAITS YOU IN THE NEXT CHAMBER...\n\n";
            
            
            battle_out = one_battle(fullname, s_sentinel, wdmg, ap);
            
            if (battle_out == 0){
                finish = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
                return 0;
            }
            xp += battle_out;
            
            
            values = levelup(hp,ap,sp,mp,xp,lvl);
            
            if (values[0] != 0){
                hp = values[0];
                ap = values[1];
                sp = values[2];
                mp = values[3];
                xp = values[4];
                lvl = values [5];
            } else {
                cout << "// No level up available at this moment.\n\n\n";
            }
            
            sleep_for(seconds(1));
            checkpoint = "end_temple_1";
            finish = save(name, checkpoint, hp, ap, sp, mp, lvl, xp, total_temples, weapon, wdmg);
            return 0;
        }
      
    }
    

    
    
}
